<ul>
	<?php foreach($children as $child): ?>
    <li id="page-<?php echo $child->id; ?>-<?php echo $level; ?>" class="node level-<?php echo $level; if ( ! $child->has_children) echo ' no-children'; else if ($child->is_expanded) echo ' children-visible'; else echo ' children-hidden'; ?>">
		<?php if ($child->has_children): ?><img align="top" alt="toggle children" class="expander" src="<?php echo URI_PUBLIC ?>wolf/admin/images/<?php echo $child->is_expanded ? 'collapse': 'expand'; ?>.png" /><?php endif; ?>
		<input type="checkbox" value="<?php echo $child->id; ?>"<?php if ($child->is_related){ ?> checked="checked"<?php } ?><?php if ($pageid == $child->id){?> disabled="disabled"<?php } ?> /> <?php echo $child->title; ?>

		<?php if (! empty($child->behavior_id)): ?> <small class="info">(<?php echo Inflector::humanize($child->behavior_id); ?>)</small><?php endif; ?>
		<img align="top" class="busy" id="busy-<?php echo $child->id; ?>" src="<?php echo URI_PUBLIC ?>wolf/admin/images/spinner.gif" style="display: none;" title="" />

		<span class="status">
		<?php switch ($child->status_id) {
			  case Page::STATUS_DRAFT: echo __('Draft'); break;
			  case Page::STATUS_PREVIEW: echo __('Preview'); break;
			  case Page::STATUS_PUBLISHED: echo __('Published'); break;
			  case Page::STATUS_HIDDEN: echo __('Hidden'); break;
		} ?>
		</span>

		<?php if ($child->is_expanded) echo $child->children_rows; ?>
    </li>
<?php endforeach; ?>
</ul>
